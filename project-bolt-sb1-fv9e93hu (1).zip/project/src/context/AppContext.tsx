import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { 
  Hospital, 
  Doctor, 
  Patient, 
  Appointment, 
  HospitalAdmin, 
  User, 
  UserRole,
  Department,
  TimeSlot
} from '../types';

interface AppState {
  currentUser: User | null;
  hospitals: Hospital[];
  doctors: Doctor[];
  patients: Patient[];
  appointments: Appointment[];
  hospitalAdmins: HospitalAdmin[];
}

type AppAction = 
  | { type: 'SET_USER'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'ADD_HOSPITAL'; payload: Hospital }
  | { type: 'ADD_DOCTOR'; payload: Doctor }
  | { type: 'ADD_PATIENT'; payload: Patient }
  | { type: 'ADD_APPOINTMENT'; payload: Appointment }
  | { type: 'ADD_HOSPITAL_ADMIN'; payload: HospitalAdmin }
  | { type: 'UPDATE_DOCTOR'; payload: Doctor }
  | { type: 'UPDATE_HOSPITAL'; payload: Hospital }
  | { type: 'BOOK_SLOT'; payload: { doctorId: string; hospitalId: string; slotId: string; appointmentId: string } };

const initialState: AppState = {
  currentUser: null,
  hospitals: [
    {
      id: '1',
      name: 'City General Hospital',
      location: 'Downtown',
      adminId: 'admin1',
      departments: [
        { id: 'dept1', name: 'Cardiology', hospitalId: '1' },
        { id: 'dept2', name: 'Orthopedics', hospitalId: '1' },
        { id: 'dept3', name: 'Pediatrics', hospitalId: '1' },
        { id: 'dept4', name: 'General Medicine', hospitalId: '1' }
      ]
    },
    {
      id: '2',
      name: 'Metro Medical Center',
      location: 'Uptown',
      adminId: 'admin2',
      departments: [
        { id: 'dept5', name: 'Neurology', hospitalId: '2' },
        { id: 'dept6', name: 'Dermatology', hospitalId: '2' },
        { id: 'dept7', name: 'General Medicine', hospitalId: '2' },
        { id: 'dept8', name: 'Surgery', hospitalId: '2' }
      ]
    },
    {
      id: '3',
      name: 'Sunrise Healthcare',
      location: 'Westside',
      adminId: 'admin3',
      departments: [
        { id: 'dept9', name: 'Gynecology', hospitalId: '3' },
        { id: 'dept10', name: 'Psychiatry', hospitalId: '3' },
        { id: 'dept11', name: 'Oncology', hospitalId: '3' }
      ]
    }
  ],
  doctors: [
    {
      id: 'doc1',
      name: 'Dr. Sarah Johnson',
      qualifications: ['MBBS', 'MD Cardiology'],
      specializations: ['Cardiology'],
      yearsOfExperience: 8,
      hospitalAssociations: [
        {
          hospitalId: '1',
          departmentIds: ['dept1'],
          consultationFee: 800,
          availableSlots: [
            { 
              id: 'slot1', 
              date: '2025-01-20', 
              startTime: '09:00', 
              endTime: '09:30', 
              isBooked: false 
            },
            { 
              id: 'slot2', 
              date: '2025-01-20', 
              startTime: '10:00', 
              endTime: '10:30', 
              isBooked: false 
            },
            { 
              id: 'slot3', 
              date: '2025-01-21', 
              startTime: '09:00', 
              endTime: '09:30', 
              isBooked: false 
            }
          ]
        }
      ]
    },
    {
      id: 'doc2',
      name: 'Dr. Michael Chen',
      qualifications: ['MBBS', 'MS Orthopedics'],
      specializations: ['Orthopedics'],
      yearsOfExperience: 12,
      hospitalAssociations: [
        {
          hospitalId: '1',
          departmentIds: ['dept2'],
          consultationFee: 700,
          availableSlots: [
            { 
              id: 'slot4', 
              date: '2025-01-20', 
              startTime: '11:00', 
              endTime: '11:30', 
              isBooked: false 
            },
            { 
              id: 'slot5', 
              date: '2025-01-21', 
              startTime: '14:00', 
              endTime: '14:30', 
              isBooked: false 
            }
          ]
        }
      ]
    },
    {
      id: 'doc3',
      name: 'Dr. Emily Rodriguez',
      qualifications: ['MBBS', 'MD Neurology'],
      specializations: ['Neurology'],
      yearsOfExperience: 10,
      hospitalAssociations: [
        {
          hospitalId: '2',
          departmentIds: ['dept5'],
          consultationFee: 900,
          availableSlots: [
            { 
              id: 'slot6', 
              date: '2025-01-20', 
              startTime: '15:00', 
              endTime: '15:30', 
              isBooked: false 
            },
            { 
              id: 'slot7', 
              date: '2025-01-22', 
              startTime: '10:00', 
              endTime: '10:30', 
              isBooked: false 
            }
          ]
        }
      ]
    },
    {
      id: 'doc4',
      name: 'Dr. James Wilson',
      qualifications: ['MBBS', 'MD General Medicine'],
      specializations: ['General Medicine'],
      yearsOfExperience: 6,
      hospitalAssociations: [
        {
          hospitalId: '1',
          departmentIds: ['dept4'],
          consultationFee: 500,
          availableSlots: [
            { 
              id: 'slot8', 
              date: '2025-01-20', 
              startTime: '16:00', 
              endTime: '16:30', 
              isBooked: false 
            }
          ]
        },
        {
          hospitalId: '2',
          departmentIds: ['dept7'],
          consultationFee: 550,
          availableSlots: [
            { 
              id: 'slot9', 
              date: '2025-01-21', 
              startTime: '11:00', 
              endTime: '11:30', 
              isBooked: false 
            }
          ]
        }
      ]
    }
  ],
  patients: [
    {
      id: 'pat1',
      name: 'John Smith',
      gender: 'male',
      dateOfBirth: '1985-03-15',
      uniqueId: 'AADHAR123456789',
      appointments: []
    },
    {
      id: 'pat2',
      name: 'Maria Garcia',
      gender: 'female',
      dateOfBirth: '1990-07-22',
      uniqueId: 'PASSPORT987654321',
      appointments: []
    }
  ],
  appointments: [
    {
      id: 'apt1',
      patientId: 'pat1',
      doctorId: 'doc1',
      hospitalId: '1',
      departmentId: 'dept1',
      timeSlotId: 'slot10',
      consultationFee: 800,
      date: '2025-01-15',
      status: 'completed',
      createdAt: '2025-01-10T10:00:00Z'
    }
  ],
  hospitalAdmins: [
    { id: 'admin1', name: 'John Admin', email: 'admin1@hospital.com', hospitalId: '1' },
    { id: 'admin2', name: 'Jane Admin', email: 'admin2@hospital.com', hospitalId: '2' },
    { id: 'admin3', name: 'Robert Admin', email: 'admin3@hospital.com', hospitalId: '3' }
  ]
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    case 'LOGOUT':
      return { ...state, currentUser: null };
    case 'ADD_HOSPITAL':
      return { ...state, hospitals: [...state.hospitals, action.payload] };
    case 'ADD_DOCTOR':
      return { ...state, doctors: [...state.doctors, action.payload] };
    case 'ADD_PATIENT':
      return { ...state, patients: [...state.patients, action.payload] };
    case 'ADD_APPOINTMENT':
      return { ...state, appointments: [...state.appointments, action.payload] };
    case 'ADD_HOSPITAL_ADMIN':
      return { ...state, hospitalAdmins: [...state.hospitalAdmins, action.payload] };
    case 'UPDATE_DOCTOR':
      return {
        ...state,
        doctors: state.doctors.map(doc => 
          doc.id === action.payload.id ? action.payload : doc
        )
      };
    case 'UPDATE_HOSPITAL':
      return {
        ...state,
        hospitals: state.hospitals.map(hospital => 
          hospital.id === action.payload.id ? action.payload : hospital
        )
      };
    case 'BOOK_SLOT':
      return {
        ...state,
        doctors: state.doctors.map(doctor => {
          if (doctor.id === action.payload.doctorId) {
            return {
              ...doctor,
              hospitalAssociations: doctor.hospitalAssociations.map(association => {
                if (association.hospitalId === action.payload.hospitalId) {
                  return {
                    ...association,
                    availableSlots: association.availableSlots.map(slot => {
                      if (slot.id === action.payload.slotId) {
                        return { ...slot, isBooked: true, appointmentId: action.payload.appointmentId };
                      }
                      return slot;
                    })
                  };
                }
                return association;
              })
            };
          }
          return doctor;
        })
      };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}