import React, { useState } from 'react';
import { Plus, Building2, Trash2, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SPECIALIZATIONS } from '../../types';

export function ManageDepartments() {
  const { state, dispatch } = useApp();
  const { currentUser, hospitals, doctors } = state;
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDepartmentName, setNewDepartmentName] = useState('');

  // Find current hospital admin's hospital
  const hospitalAdmin = state.hospitalAdmins.find(admin => admin.id === currentUser?.id);
  const hospital = hospitals.find(h => h.id === hospitalAdmin?.hospitalId);

  if (!hospital) return null;

  const handleAddDepartment = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newDepartment = {
      id: `dept-${Date.now()}`,
      name: newDepartmentName,
      hospitalId: hospital.id
    };

    const updatedHospital = {
      ...hospital,
      departments: [...hospital.departments, newDepartment]
    };

    dispatch({ type: 'UPDATE_HOSPITAL', payload: updatedHospital });
    setNewDepartmentName('');
    setShowAddForm(false);
  };

  const handleDeleteDepartment = (departmentId: string) => {
    if (confirm('Are you sure you want to delete this department? This will affect doctor associations.')) {
      const updatedHospital = {
        ...hospital,
        departments: hospital.departments.filter(dept => dept.id !== departmentId)
      };

      dispatch({ type: 'UPDATE_HOSPITAL', payload: updatedHospital });
    }
  };

  // Get doctors for each department
  const getDoctorsForDepartment = (departmentId: string) => {
    return doctors.filter(doctor => 
      doctor.hospitalAssociations.some(assoc => 
        assoc.hospitalId === hospital.id && assoc.departmentIds.includes(departmentId)
      )
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Manage Departments</h1>
            <p className="text-gray-600 mt-1">{hospital.name}</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Department
          </button>
        </div>
      </div>

      {/* Add Department Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Add New Department</h2>
              <form onSubmit={handleAddDepartment}>
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Department Name
                  </label>
                  <select
                    value={newDepartmentName}
                    onChange={(e) => setNewDepartmentName(e.target.value)}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                  >
                    <option value="">Select a specialization</option>
                    {SPECIALIZATIONS.filter(spec => 
                      !hospital.departments.some(dept => dept.name === spec)
                    ).map(spec => (
                      <option key={spec} value={spec}>{spec}</option>
                    ))}
                  </select>
                </div>
                <div className="flex space-x-3">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    Add Department
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      setNewDepartmentName('');
                    }}
                    className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Departments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hospital.departments.map((department) => {
          const departmentDoctors = getDoctorsForDepartment(department.id);
          
          return (
            <div key={department.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Building2 className="h-6 w-6 text-blue-600 mr-3" />
                  <h3 className="text-lg font-semibold text-gray-900">{department.name}</h3>
                </div>
                <button
                  onClick={() => handleDeleteDepartment(department.id)}
                  className="p-2 text-gray-400 hover:text-red-600 transition-colors duration-200"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-3">
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-2" />
                  <span className="text-sm">{departmentDoctors.length} doctor{departmentDoctors.length !== 1 ? 's' : ''}</span>
                </div>

                {departmentDoctors.length > 0 && (
                  <div className="border-t pt-3">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Associated Doctors:</h4>
                    <div className="space-y-2">
                      {departmentDoctors.map(doctor => (
                        <div key={doctor.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                          <span className="text-sm text-gray-900">{doctor.name}</span>
                          <span className="text-xs text-gray-600">{doctor.yearsOfExperience}y exp</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {hospital.departments.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No departments yet</h3>
            <p className="text-gray-600 mb-4">Add your first department to start organizing your hospital</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Department
            </button>
          </div>
        )}
      </div>
    </div>
  );
}