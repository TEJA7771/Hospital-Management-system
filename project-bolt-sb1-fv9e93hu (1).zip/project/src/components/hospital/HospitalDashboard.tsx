import React from 'react';
import { 
  Building2, 
  Users, 
  Calendar, 
  DollarSign, 
  TrendingUp,
  Stethoscope,
  MapPin
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export function HospitalDashboard() {
  const { state } = useApp();
  const { currentUser, hospitals, doctors, appointments } = state;
  
  // Find current hospital admin's hospital
  const hospitalAdmin = state.hospitalAdmins.find(admin => admin.id === currentUser?.id);
  const hospital = hospitals.find(h => h.id === hospitalAdmin?.hospitalId);
  
  if (!hospital) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Hospital not found</h1>
        </div>
      </div>
    );
  }

  // Get doctors associated with this hospital
  const hospitalDoctors = doctors.filter(doctor => 
    doctor.hospitalAssociations.some(assoc => assoc.hospitalId === hospital.id)
  );

  // Get appointments for this hospital
  const hospitalAppointments = appointments.filter(apt => apt.hospitalId === hospital.id);

  // Calculate revenue
  const totalRevenue = hospitalAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0);
  const hospitalRevenue = totalRevenue * 0.4; // 40% goes to hospital

  // Revenue by department
  const revenueByDepartment = hospital.departments.map(dept => {
    const deptAppointments = hospitalAppointments.filter(apt => apt.departmentId === dept.id);
    const deptRevenue = deptAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0) * 0.4;
    return { ...dept, revenue: deptRevenue, appointments: deptAppointments.length };
  });

  // Revenue by doctor
  const revenueByDoctor = hospitalDoctors.map(doctor => {
    const doctorAppointments = hospitalAppointments.filter(apt => apt.doctorId === doctor.id);
    const doctorRevenue = doctorAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0) * 0.4;
    return { 
      ...doctor, 
      revenue: doctorRevenue, 
      appointments: doctorAppointments.length,
      totalFee: doctorAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0)
    };
  });

  const stats = [
    {
      label: 'Total Doctors',
      value: hospitalDoctors.length,
      icon: Stethoscope,
      color: 'bg-blue-500',
      change: '+2 this month'
    },
    {
      label: 'Total Consultations',
      value: hospitalAppointments.length,
      icon: Calendar,
      color: 'bg-green-500',
      change: '+15 this month'
    },
    {
      label: 'Hospital Revenue',
      value: `₹${hospitalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-purple-500',
      change: '+8.5% this month'
    },
    {
      label: 'Departments',
      value: hospital.departments.length,
      icon: Building2,
      color: 'bg-orange-500',
      change: 'All active'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center mb-2">
          <Building2 className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{hospital.name}</h1>
            <div className="flex items-center text-gray-600 mt-1">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{hospital.location}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <p className="text-sm text-green-600 mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color} rounded-lg p-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Revenue Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Revenue by Department */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Revenue by Department</h2>
          <div className="space-y-4">
            {revenueByDepartment.map((dept) => (
              <div key={dept.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">{dept.name}</h3>
                  <p className="text-sm text-gray-600">{dept.appointments} consultations</p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">₹{dept.revenue.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">40% share</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue by Doctor */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Revenue by Doctor</h2>
          <div className="space-y-4">
            {revenueByDoctor.map((doctor) => (
              <div key={doctor.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">{doctor.name}</h3>
                  <p className="text-sm text-gray-600">
                    {doctor.specializations.join(', ')} • {doctor.appointments} consultations
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">₹{doctor.revenue.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">From ₹{doctor.totalFee.toLocaleString()}</p>
                </div>
              </div>
            ))}
            {revenueByDoctor.length === 0 && (
              <p className="text-gray-500 text-center py-4">No doctors associated yet</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Appointments</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Patient</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Doctor</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Department</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Fee</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
              </tr>
            </thead>
            <tbody>
              {hospitalAppointments.slice(0, 5).map((appointment) => {
                const doctor = doctors.find(d => d.id === appointment.doctorId);
                const patient = state.patients.find(p => p.id === appointment.patientId);
                const department = hospital.departments.find(d => d.id === appointment.departmentId);
                
                return (
                  <tr key={appointment.id} className="border-b border-gray-100">
                    <td className="py-3 px-4 text-gray-900">{patient?.name || 'Unknown'}</td>
                    <td className="py-3 px-4 text-gray-900">{doctor?.name || 'Unknown'}</td>
                    <td className="py-3 px-4 text-gray-600">{department?.name || 'Unknown'}</td>
                    <td className="py-3 px-4 text-gray-600">{appointment.date}</td>
                    <td className="py-3 px-4 text-gray-900">₹{appointment.consultationFee.toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        appointment.status === 'completed' 
                          ? 'bg-green-100 text-green-800'
                          : appointment.status === 'booked'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {appointment.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {hospitalAppointments.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No appointments found
            </div>
          )}
        </div>
      </div>
    </div>
  );
}