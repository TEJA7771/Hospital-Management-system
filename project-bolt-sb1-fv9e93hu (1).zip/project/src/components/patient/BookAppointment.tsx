import React, { useState } from 'react';
import { Search, Filter, Calendar, Clock, MapPin, Stethoscope, Building2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SPECIALIZATIONS } from '../../types';

export function BookAppointment() {
  const { state, dispatch } = useApp();
  const { currentUser, doctors, hospitals } = state;
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialization, setSelectedSpecialization] = useState('');
  const [selectedHospital, setSelectedHospital] = useState('');
  const [selectedDoctor, setSelectedDoctor] = useState('');
  const [selectedHospitalForBooking, setSelectedHospitalForBooking] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');

  // Find current patient
  const patient = state.patients.find(p => p.id === currentUser?.id);
  
  if (!patient) return null;

  // Filter doctors based on search criteria
  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specializations.some(spec => spec.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesSpecialization = !selectedSpecialization || doctor.specializations.includes(selectedSpecialization);
    const matchesHospital = !selectedHospital || doctor.hospitalAssociations.some(assoc => assoc.hospitalId === selectedHospital);
    
    return matchesSearch && matchesSpecialization && matchesHospital && doctor.hospitalAssociations.length > 0;
  });

  const handleBookAppointment = () => {
    if (!selectedDoctor || !selectedHospitalForBooking || !selectedSlot) return;

    const doctor = doctors.find(d => d.id === selectedDoctor);
    const hospital = hospitals.find(h => h.id === selectedHospitalForBooking);
    const association = doctor?.hospitalAssociations.find(assoc => assoc.hospitalId === selectedHospitalForBooking);
    const slot = association?.availableSlots.find(s => s.id === selectedSlot);
    
    if (!doctor || !hospital || !association || !slot) return;

    // Find department (use first matching specialization)
    const department = hospital.departments.find(dept => doctor.specializations.includes(dept.name));
    if (!department) return;

    const appointmentId = `apt-${Date.now()}`;
    
    const appointment = {
      id: appointmentId,
      patientId: patient.id,
      doctorId: selectedDoctor,
      hospitalId: selectedHospitalForBooking,
      departmentId: department.id,
      timeSlotId: selectedSlot,
      consultationFee: association.consultationFee,
      date: slot.date,
      status: 'booked' as const,
      createdAt: new Date().toISOString()
    };

    // Book the slot
    dispatch({ 
      type: 'BOOK_SLOT', 
      payload: { 
        doctorId: selectedDoctor, 
        hospitalId: selectedHospitalForBooking, 
        slotId: selectedSlot, 
        appointmentId 
      } 
    });

    // Add appointment
    dispatch({ type: 'ADD_APPOINTMENT', payload: appointment });

    // Reset selection
    setSelectedDoctor('');
    setSelectedHospitalForBooking('');
    setSelectedSlot('');

    alert('Appointment booked successfully!');
  };

  const getDoctorAvailableSlots = (doctorId: string, hospitalId: string) => {
    const doctor = doctors.find(d => d.id === doctorId);
    const association = doctor?.hospitalAssociations.find(assoc => assoc.hospitalId === hospitalId);
    return association?.availableSlots.filter(slot => !slot.isBooked) || [];
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Book Appointment</h1>
        <p className="text-gray-600">Find and book appointments with doctors</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search doctors or specializations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            />
          </div>

          <div>
            <select
              value={selectedSpecialization}
              onChange={(e) => setSelectedSpecialization(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            >
              <option value="">All Specializations</option>
              {SPECIALIZATIONS.map(spec => (
                <option key={spec} value={spec}>{spec}</option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedHospital}
              onChange={(e) => setSelectedHospital(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
            >
              <option value="">All Hospitals</option>
              {hospitals.map(hospital => (
                <option key={hospital.id} value={hospital.id}>{hospital.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Doctors List */}
      <div className="space-y-6">
        {filteredDoctors.map((doctor) => (
          <div key={doctor.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <div className="bg-blue-100 rounded-full p-3 mr-4">
                  <Stethoscope className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{doctor.name}</h3>
                  <p className="text-gray-600">{doctor.specializations.join(', ')}</p>
                  <p className="text-sm text-gray-500">{doctor.yearsOfExperience} years experience</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {doctor.qualifications.map((qual, index) => (
                      <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                        {qual}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Hospital Associations */}
            <div className="space-y-4">
              {doctor.hospitalAssociations.map((association) => {
                const hospital = hospitals.find(h => h.id === association.hospitalId);
                const availableSlots = association.availableSlots.filter(slot => !slot.isBooked);
                
                return (
                  <div key={association.hospitalId} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <Building2 className="h-5 w-5 text-gray-600 mr-2" />
                        <div>
                          <h4 className="font-medium text-gray-900">{hospital?.name}</h4>
                          <div className="flex items-center text-sm text-gray-600">
                            <MapPin className="h-4 w-4 mr-1" />
                            {hospital?.location}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">₹{association.consultationFee.toLocaleString()}</p>
                        <p className="text-sm text-gray-600">Consultation fee</p>
                      </div>
                    </div>

                    {availableSlots.length > 0 ? (
                      <div>
                        <h5 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          Available Slots ({availableSlots.length})
                        </h5>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                          {availableSlots.slice(0, 8).map((slot) => (
                            <button
                              key={slot.id}
                              onClick={() => {
                                setSelectedDoctor(doctor.id);
                                setSelectedHospitalForBooking(association.hospitalId);
                                setSelectedSlot(slot.id);
                              }}
                              className={`p-2 text-sm rounded border transition-colors duration-200 ${
                                selectedSlot === slot.id && selectedDoctor === doctor.id && selectedHospitalForBooking === association.hospitalId
                                  ? 'bg-blue-600 text-white border-blue-600'
                                  : 'bg-gray-50 text-gray-700 border-gray-300 hover:border-blue-600 hover:bg-blue-50'
                              }`}
                            >
                              <div className="font-medium">{slot.date}</div>
                              <div className="text-xs">{slot.startTime} - {slot.endTime}</div>
                            </button>
                          ))}
                        </div>
                        {availableSlots.length > 8 && (
                          <p className="text-sm text-gray-600">+{availableSlots.length - 8} more slots available</p>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-4 text-gray-500">
                        <Calendar className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                        <p className="text-sm">No available slots</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {filteredDoctors.length === 0 && (
          <div className="text-center py-12">
            <Stethoscope className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No doctors found</h3>
            <p className="text-gray-600">Try adjusting your search criteria</p>
          </div>
        )}
      </div>

      {/* Book Button */}
      {selectedDoctor && selectedHospitalForBooking && selectedSlot && (
        <div className="fixed bottom-6 right-6">
          <button
            onClick={handleBookAppointment}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-blue-700 transition-colors duration-200 transform hover:scale-105"
          >
            Book Appointment
          </button>
        </div>
      )}
    </div>
  );
}