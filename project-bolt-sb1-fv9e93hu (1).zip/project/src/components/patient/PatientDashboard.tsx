import React from 'react';
import { Calendar, Clock, Guitar as Hospital, FileText, User } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export function PatientDashboard() {
  const { state } = useApp();
  const { currentUser, appointments, doctors, hospitals } = state;
  
  // Find current patient
  const patient = state.patients.find(p => p.id === currentUser?.id);
  
  if (!patient) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Patient profile not found</h1>
        </div>
      </div>
    );
  }

  // Get patient's appointments
  const patientAppointments = appointments.filter(apt => apt.patientId === patient.id);

  // Separate upcoming and past appointments
  const today = new Date().toISOString().split('T')[0];
  const upcomingAppointments = patientAppointments.filter(apt => apt.date >= today && apt.status === 'booked');
  const pastAppointments = patientAppointments.filter(apt => apt.date < today || apt.status === 'completed');

  // Calculate total spent
  const totalSpent = patientAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0);

  // Get unique hospitals visited
  const hospitalsVisited = [...new Set(patientAppointments.map(apt => apt.hospitalId))];

  const stats = [
    {
      label: 'Total Appointments',
      value: patientAppointments.length,
      icon: Calendar,
      color: 'bg-blue-500'
    },
    {
      label: 'Upcoming',
      value: upcomingAppointments.length,
      icon: Clock,
      color: 'bg-green-500'
    },
    {
      label: 'Hospitals Visited',
      value: hospitalsVisited.length,
      icon: Hospital,
      color: 'bg-purple-500'
    },
    {
      label: 'Total Spent',
      value: `₹${totalSpent.toLocaleString()}`,
      icon: FileText,
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <User className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{patient.name}</h1>
            <p className="text-gray-600 capitalize">{patient.gender} • DOB: {patient.dateOfBirth}</p>
            <p className="text-sm text-gray-500">ID: {patient.uniqueId}</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`${stat.color} rounded-lg p-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Clock className="h-5 w-5 mr-2 text-green-600" />
            Upcoming Appointments
          </h2>
          <div className="space-y-4">
            {upcomingAppointments.map((appointment) => {
              const doctor = doctors.find(d => d.id === appointment.doctorId);
              const hospital = hospitals.find(h => h.id === appointment.hospitalId);
              const department = hospital?.departments.find(d => d.id === appointment.departmentId);
              
              return (
                <div key={appointment.id} className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-gray-900">{doctor?.name}</h3>
                      <span className="text-sm text-gray-600">{appointment.date}</span>
                    </div>
                    <p className="text-sm text-gray-600">{hospital?.name} • {department?.name}</p>
                    <p className="text-sm text-gray-500">{doctor?.specializations.join(', ')}</p>
                  </div>
                  <div className="text-right ml-4">
                    <p className="font-semibold text-gray-900">₹{appointment.consultationFee.toLocaleString()}</p>
                    <span className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">
                      {appointment.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Appointment History */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <FileText className="h-5 w-5 mr-2 text-blue-600" />
          Appointment History
        </h2>
        
        {patientAppointments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Doctor</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Hospital</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Department</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Fee</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-700">Status</th>
                </tr>
              </thead>
              <tbody>
                {patientAppointments
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((appointment) => {
                    const doctor = doctors.find(d => d.id === appointment.doctorId);
                    const hospital = hospitals.find(h => h.id === appointment.hospitalId);
                    const department = hospital?.departments.find(d => d.id === appointment.departmentId);
                    
                    return (
                      <tr key={appointment.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4 text-gray-900">{appointment.date}</td>
                        <td className="py-3 px-4">
                          <div>
                            <p className="text-gray-900 font-medium">{doctor?.name}</p>
                            <p className="text-sm text-gray-600">{doctor?.specializations.join(', ')}</p>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-gray-900">{hospital?.name}</td>
                        <td className="py-3 px-4 text-gray-600">{department?.name}</td>
                        <td className="py-3 px-4 text-gray-900">₹{appointment.consultationFee.toLocaleString()}</td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            appointment.status === 'completed' 
                              ? 'bg-green-100 text-green-800'
                              : appointment.status === 'booked'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {appointment.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Appointments Yet</h3>
            <p className="text-gray-600">Book your first appointment to get started</p>
          </div>
        )}
      </div>
    </div>
  );
}