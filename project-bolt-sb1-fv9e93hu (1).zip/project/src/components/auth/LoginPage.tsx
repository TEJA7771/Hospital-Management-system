import React, { useState } from 'react';
import { Guitar as Hospital, UserCheck, Stethoscope, Users } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';

interface LoginPageProps {
  onViewChange: (view: string) => void;
}

export function LoginPage({ onViewChange }: LoginPageProps) {
  const { state, dispatch } = useApp();
  const [selectedRole, setSelectedRole] = useState<UserRole>('patient');
  const [email, setEmail] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock authentication - find user by email and role
    let user = null;
    
    if (selectedRole === 'hospital-admin') {
      const admin = state.hospitalAdmins.find(a => a.email === email);
      if (admin) {
        user = { id: admin.id, name: admin.name, email: admin.email, role: selectedRole };
      }
    } else if (selectedRole === 'doctor') {
      // For doctors, match by name (simplified for demo)
      const emailName = email.split('@')[0].toLowerCase();
      const doctor = state.doctors.find(d => 
        d.name.toLowerCase().replace(/\s+/g, '').includes(emailName) ||
        d.name.toLowerCase().replace('dr.', '').trim().replace(/\s+/g, '').includes(emailName)
      );
      if (doctor) {
        user = { id: doctor.id, name: doctor.name, email, role: selectedRole };
      }
    } else if (selectedRole === 'patient') {
      // For patients, match by name (simplified for demo)
      const emailName = email.split('@')[0].toLowerCase();
      const patient = state.patients.find(p => 
        p.name.toLowerCase().replace(/\s+/g, '').includes(emailName)
      );
      if (patient) {
        user = { id: patient.id, name: patient.name, email, role: selectedRole };
      }
    }

    if (user) {
      dispatch({ type: 'SET_USER', payload: user });
      // Navigate to appropriate dashboard
      switch (selectedRole) {
        case 'hospital-admin':
          onViewChange('dashboard');
          break;
        case 'doctor':
          onViewChange('doctor-dashboard');
          break;
        case 'patient':
          onViewChange('patient-dashboard');
          break;
      }
    } else {
      alert('User not found. Please check the demo credentials or register first.');
    }
  };

  const roleOptions = [
    { 
      value: 'hospital-admin' as UserRole, 
      label: 'Hospital Admin', 
      icon: Hospital,
      description: 'Manage hospital operations and departments'
    },
    { 
      value: 'doctor' as UserRole, 
      label: 'Doctor', 
      icon: Stethoscope,
      description: 'Manage practice and appointments'
    },
    { 
      value: 'patient' as UserRole, 
      label: 'Patient', 
      icon: Users,
      description: 'Book appointments and manage health records'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="px-8 py-10">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div className="bg-blue-600 rounded-full p-3">
                  <Hospital className="h-8 w-8 text-white" />
                </div>
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to MedFlow</h1>
              <p className="text-gray-600">Comprehensive Hospital Management System</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Your Role
                </label>
                <div className="space-y-3">
                  {roleOptions.map((option) => {
                    const Icon = option.icon;
                    return (
                      <label
                        key={option.value}
                        className={`relative flex items-center p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                          selectedRole === option.value
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="radio"
                          value={option.value}
                          checked={selectedRole === option.value}
                          onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                          className="sr-only"
                        />
                        <Icon className={`h-5 w-5 mr-3 ${
                          selectedRole === option.value ? 'text-blue-600' : 'text-gray-400'
                        }`} />
                        <div>
                          <p className={`font-medium ${
                            selectedRole === option.value ? 'text-blue-900' : 'text-gray-900'
                          }`}>
                            {option.label}
                          </p>
                          <p className="text-sm text-gray-500">{option.description}</p>
                        </div>
                        {selectedRole === option.value && (
                          <UserCheck className="h-5 w-5 text-blue-600 ml-auto" />
                        )}
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all duration-200"
                  placeholder="Enter your email"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200 transform hover:scale-[1.02]"
              >
                Sign In
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <button
                  onClick={() => onViewChange('register')}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  Register here
                </button>
              </p>
            </div>

            {/* Demo credentials */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Demo Credentials:</h4>
              <div className="text-xs text-gray-600 space-y-1">
                <p><span className="font-medium">Hospital Admin:</span> admin1@hospital.com</p>
                <p><span className="font-medium">Doctor:</span> sarah@doctor.com (Dr. Sarah Johnson)</p>
                <p><span className="font-medium">Doctor:</span> michael@doctor.com (Dr. Michael Chen)</p>
                <p><span className="font-medium">Patient:</span> john@patient.com (John Smith)</p>
                <p><span className="font-medium">Patient:</span> maria@patient.com (Maria Garcia)</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}