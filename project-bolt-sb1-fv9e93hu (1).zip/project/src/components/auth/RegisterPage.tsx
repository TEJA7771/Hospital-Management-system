import React, { useState } from 'react';
import { ArrowLeft, Guitar as Hospital, Stethoscope, User, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { UserRole, SPECIALIZATIONS } from '../../types';

interface RegisterPageProps {
  onViewChange: (view: string) => void;
}

export function RegisterPage({ onViewChange }: RegisterPageProps) {
  const { state, dispatch } = useApp();
  const [selectedRole, setSelectedRole] = useState<UserRole>('patient');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    // Hospital admin fields
    hospitalName: '',
    hospitalLocation: '',
    // Doctor fields
    qualifications: [''],
    specializations: [] as string[],
    yearsOfExperience: 0,
    // Patient fields
    gender: 'male' as 'male' | 'female' | 'other',
    dateOfBirth: '',
    uniqueId: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const id = `${selectedRole}-${Date.now()}`;
    
    if (selectedRole === 'hospital-admin') {
      // Create hospital first
      const hospitalId = `hospital-${Date.now()}`;
      const hospital = {
        id: hospitalId,
        name: formData.hospitalName,
        location: formData.hospitalLocation,
        departments: [],
        adminId: id
      };
      
      const admin = {
        id,
        name: formData.name,
        email: formData.email,
        hospitalId
      };
      
      dispatch({ type: 'ADD_HOSPITAL', payload: hospital });
      dispatch({ type: 'ADD_HOSPITAL_ADMIN', payload: admin });
      
    } else if (selectedRole === 'doctor') {
      const doctor = {
        id,
        name: formData.name,
        qualifications: formData.qualifications.filter(q => q.trim()),
        specializations: formData.specializations,
        yearsOfExperience: formData.yearsOfExperience,
        hospitalAssociations: []
      };
      
      dispatch({ type: 'ADD_DOCTOR', payload: doctor });
      
    } else if (selectedRole === 'patient') {
      const patient = {
        id,
        name: formData.name,
        gender: formData.gender,
        dateOfBirth: formData.dateOfBirth,
        uniqueId: formData.uniqueId,
        appointments: []
      };
      
      dispatch({ type: 'ADD_PATIENT', payload: patient });
    }
    
    alert('Registration successful! You can now log in.');
    onViewChange('login');
  };

  const addQualification = () => {
    setFormData(prev => ({
      ...prev,
      qualifications: [...prev.qualifications, '']
    }));
  };

  const updateQualification = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      qualifications: prev.qualifications.map((q, i) => i === index ? value : q)
    }));
  };

  const toggleSpecialization = (spec: string) => {
    setFormData(prev => ({
      ...prev,
      specializations: prev.specializations.includes(spec)
        ? prev.specializations.filter(s => s !== spec)
        : [...prev.specializations, spec]
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="px-8 py-6 border-b border-gray-200">
            <div className="flex items-center">
              <button
                onClick={() => onViewChange('login')}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                <ArrowLeft className="h-5 w-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Create Account</h1>
                <p className="text-gray-600">Join the MedFlow platform</p>
              </div>
            </div>
          </div>

          <div className="px-8 py-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Role Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  I want to register as a
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'hospital-admin' as UserRole, label: 'Hospital Admin', icon: Hospital },
                    { value: 'doctor' as UserRole, label: 'Doctor', icon: Stethoscope },
                    { value: 'patient' as UserRole, label: 'Patient', icon: User }
                  ].map((option) => {
                    const Icon = option.icon;
                    return (
                      <label
                        key={option.value}
                        className={`flex flex-col items-center p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                          selectedRole === option.value
                            ? 'border-blue-600 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="radio"
                          value={option.value}
                          checked={selectedRole === option.value}
                          onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                          className="sr-only"
                        />
                        <Icon className={`h-6 w-6 mb-2 ${
                          selectedRole === option.value ? 'text-blue-600' : 'text-gray-400'
                        }`} />
                        <span className={`text-sm font-medium ${
                          selectedRole === option.value ? 'text-blue-900' : 'text-gray-700'
                        }`}>
                          {option.label}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Common fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({...prev, email: e.target.value}))}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                  />
                </div>
              </div>

              {/* Hospital Admin specific fields */}
              {selectedRole === 'hospital-admin' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Hospital Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Hospital Name *
                      </label>
                      <input
                        type="text"
                        value={formData.hospitalName}
                        onChange={(e) => setFormData(prev => ({...prev, hospitalName: e.target.value}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Location *
                      </label>
                      <input
                        type="text"
                        value={formData.hospitalLocation}
                        onChange={(e) => setFormData(prev => ({...prev, hospitalLocation: e.target.value}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Doctor specific fields */}
              {selectedRole === 'doctor' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Professional Information</h3>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Years of Experience *
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={formData.yearsOfExperience}
                      onChange={(e) => setFormData(prev => ({...prev, yearsOfExperience: parseInt(e.target.value) || 0}))}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Qualifications *
                    </label>
                    {formData.qualifications.map((qual, index) => (
                      <div key={index} className="flex mb-2">
                        <input
                          type="text"
                          value={qual}
                          onChange={(e) => updateQualification(index, e.target.value)}
                          placeholder="e.g., MBBS, MD, etc."
                          className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                        />
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={addQualification}
                      className="flex items-center text-blue-600 hover:text-blue-700 text-sm font-medium"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Add Qualification
                    </button>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Specializations *
                    </label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {SPECIALIZATIONS.map((spec) => (
                        <label
                          key={spec}
                          className={`flex items-center p-2 rounded border cursor-pointer transition-colors duration-200 ${
                            formData.specializations.includes(spec)
                              ? 'bg-blue-50 border-blue-600'
                              : 'border-gray-300 hover:border-gray-400'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={formData.specializations.includes(spec)}
                            onChange={() => toggleSpecialization(spec)}
                            className="sr-only"
                          />
                          <span className={`text-sm ${
                            formData.specializations.includes(spec) ? 'text-blue-900' : 'text-gray-700'
                          }`}>
                            {spec}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Patient specific fields */}
              {selectedRole === 'patient' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-gray-900 border-b pb-2">Personal Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Gender *
                      </label>
                      <select
                        value={formData.gender}
                        onChange={(e) => setFormData(prev => ({...prev, gender: e.target.value as any}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      >
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Date of Birth *
                      </label>
                      <input
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => setFormData(prev => ({...prev, dateOfBirth: e.target.value}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        ID Number *
                      </label>
                      <input
                        type="text"
                        value={formData.uniqueId}
                        onChange={(e) => setFormData(prev => ({...prev, uniqueId: e.target.value}))}
                        placeholder="Aadhar/Passport"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200 transform hover:scale-[1.02]"
                >
                  Create Account
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}