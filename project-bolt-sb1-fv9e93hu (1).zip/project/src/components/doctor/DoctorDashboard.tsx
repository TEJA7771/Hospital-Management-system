import React from 'react';
import { DollarSign, Calendar, Guitar as Hospital, TrendingUp, Stethoscope, Clock } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export function DoctorDashboard() {
  const { state } = useApp();
  const { currentUser, hospitals, appointments } = state;
  
  // Find current doctor
  const doctor = state.doctors.find(d => d.id === currentUser?.id);
  
  if (!doctor) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Doctor profile not found</h1>
        </div>
      </div>
    );
  }

  // Get doctor's appointments
  const doctorAppointments = appointments.filter(apt => apt.doctorId === doctor.id);

  // Calculate total earnings (60% of consultation fees)
  const totalEarnings = doctorAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0) * 0.6;

  // Calculate earnings by hospital
  const earningsByHospital = doctor.hospitalAssociations.map(assoc => {
    const hospital = hospitals.find(h => h.id === assoc.hospitalId);
    const hospitalAppointments = doctorAppointments.filter(apt => apt.hospitalId === assoc.hospitalId);
    const earnings = hospitalAppointments.reduce((sum, apt) => sum + apt.consultationFee, 0) * 0.6;
    
    return {
      hospital: hospital?.name || 'Unknown Hospital',
      appointments: hospitalAppointments.length,
      earnings,
      consultationFee: assoc.consultationFee
    };
  });

  // Calculate total available slots
  const totalSlots = doctor.hospitalAssociations.reduce((sum, assoc) => 
    sum + assoc.availableSlots.length, 0
  );

  const bookedSlots = doctor.hospitalAssociations.reduce((sum, assoc) => 
    sum + assoc.availableSlots.filter(slot => slot.isBooked).length, 0
  );

  const stats = [
    {
      label: 'Total Earnings',
      value: `₹${totalEarnings.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-green-500',
      change: '+12% this month'
    },
    {
      label: 'Total Consultations',
      value: doctorAppointments.length,
      icon: Calendar,
      color: 'bg-blue-500',
      change: '+8 this month'
    },
    {
      label: 'Hospitals Associated',
      value: doctor.hospitalAssociations.length,
      icon: Hospital,
      color: 'bg-purple-500',
      change: 'Active partnerships'
    },
    {
      label: 'Available Slots',
      value: `${totalSlots - bookedSlots}/${totalSlots}`,
      icon: Clock,
      color: 'bg-orange-500',
      change: 'This week'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <Stethoscope className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{doctor.name}</h1>
            <p className="text-gray-600">{doctor.specializations.join(', ')}</p>
            <p className="text-sm text-gray-500">{doctor.yearsOfExperience} years experience</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {doctor.qualifications.map((qual, index) => (
            <span 
              key={index}
              className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
            >
              {qual}
            </span>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  <p className="text-sm text-green-600 mt-1">{stat.change}</p>
                </div>
                <div className={`${stat.color} rounded-lg p-3`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Earnings by Hospital */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Earnings by Hospital</h2>
          <div className="space-y-4">
            {earningsByHospital.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">{item.hospital}</h3>
                  <p className="text-sm text-gray-600">
                    {item.appointments} consultations • ₹{item.consultationFee} per session
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">₹{item.earnings.toLocaleString()}</p>
                  <p className="text-sm text-gray-600">60% share</p>
                </div>
              </div>
            ))}
            {earningsByHospital.length === 0 && (
              <p className="text-gray-500 text-center py-4">No hospital associations yet</p>
            )}
          </div>
        </div>

        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Appointments</h2>
          <div className="space-y-4">
            {doctorAppointments.slice(0, 5).map((appointment) => {
              const patient = state.patients.find(p => p.id === appointment.patientId);
              const hospital = hospitals.find(h => h.id === appointment.hospitalId);
              
              return (
                <div key={appointment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <h3 className="font-medium text-gray-900">{patient?.name || 'Unknown Patient'}</h3>
                    <p className="text-sm text-gray-600">
                      {hospital?.name} • {appointment.date}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">₹{appointment.consultationFee.toLocaleString()}</p>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      appointment.status === 'completed' 
                        ? 'bg-green-100 text-green-800'
                        : appointment.status === 'booked'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {appointment.status}
                    </span>
                  </div>
                </div>
              );
            })}
            {doctorAppointments.length === 0 && (
              <p className="text-gray-500 text-center py-4">No appointments yet</p>
            )}
          </div>
        </div>
      </div>

      {/* Availability Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Availability Summary</h2>
        <div className="space-y-4">
          {doctor.hospitalAssociations.map((assoc) => {
            const hospital = hospitals.find(h => h.id === assoc.hospitalId);
            const availableSlots = assoc.availableSlots.filter(slot => !slot.isBooked);
            const bookedSlots = assoc.availableSlots.filter(slot => slot.isBooked);
            
            return (
              <div key={assoc.hospitalId} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-gray-900">{hospital?.name}</h3>
                  <span className="text-sm text-gray-600">
                    Fee: ₹{assoc.consultationFee.toLocaleString()}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-green-50 rounded">
                    <p className="text-lg font-semibold text-green-600">{availableSlots.length}</p>
                    <p className="text-sm text-green-600">Available Slots</p>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded">
                    <p className="text-lg font-semibold text-blue-600">{bookedSlots.length}</p>
                    <p className="text-sm text-blue-600">Booked Slots</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}