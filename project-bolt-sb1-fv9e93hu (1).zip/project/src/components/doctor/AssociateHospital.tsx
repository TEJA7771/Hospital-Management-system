import React, { useState } from 'react';
import { Plus, Building2, Users, DollarSign, CheckCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export function AssociateHospital() {
  const { state, dispatch } = useApp();
  const { currentUser, hospitals } = state;
  const [showJoinForm, setShowJoinForm] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState('');
  const [consultationFee, setConsultationFee] = useState('');
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);

  // Find current doctor
  const doctor = state.doctors.find(d => d.id === currentUser?.id);
  
  if (!doctor) return null;

  // Get hospitals where doctor can join (has matching departments)
  const availableHospitals = hospitals.filter(hospital => {
    // Check if doctor is already associated
    const isAlreadyAssociated = doctor.hospitalAssociations.some(assoc => assoc.hospitalId === hospital.id);
    if (isAlreadyAssociated) return false;

    // Check if hospital has departments matching doctor's specializations
    return hospital.departments.some(dept => doctor.specializations.includes(dept.name));
  });

  const handleJoinHospital = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newAssociation = {
      hospitalId: selectedHospital,
      departmentIds: selectedDepartments,
      consultationFee: parseInt(consultationFee),
      availableSlots: []
    };

    const updatedDoctor = {
      ...doctor,
      hospitalAssociations: [...doctor.hospitalAssociations, newAssociation]
    };

    dispatch({ type: 'UPDATE_DOCTOR', payload: updatedDoctor });
    
    // Reset form
    setSelectedHospital('');
    setConsultationFee('');
    setSelectedDepartments([]);
    setShowJoinForm(false);
  };

  const getMatchingDepartments = (hospitalId: string) => {
    const hospital = hospitals.find(h => h.id === hospitalId);
    if (!hospital) return [];
    
    return hospital.departments.filter(dept => doctor.specializations.includes(dept.name));
  };

  const toggleDepartment = (deptId: string) => {
    setSelectedDepartments(prev => 
      prev.includes(deptId)
        ? prev.filter(id => id !== deptId)
        : [...prev, deptId]
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Hospital Associations</h1>
            <p className="text-gray-600 mt-1">Manage your hospital partnerships</p>
          </div>
          {availableHospitals.length > 0 && (
            <button
              onClick={() => setShowJoinForm(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
            >
              <Plus className="h-4 w-4 mr-2" />
              Join Hospital
            </button>
          )}
        </div>
      </div>

      {/* Join Hospital Modal */}
      {showJoinForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Join Hospital</h2>
              <form onSubmit={handleJoinHospital}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Hospital
                    </label>
                    <select
                      value={selectedHospital}
                      onChange={(e) => {
                        setSelectedHospital(e.target.value);
                        setSelectedDepartments([]);
                      }}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                    >
                      <option value="">Choose a hospital</option>
                      {availableHospitals.map(hospital => (
                        <option key={hospital.id} value={hospital.id}>
                          {hospital.name} - {hospital.location}
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedHospital && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Select Departments (matching your specializations)
                      </label>
                      <div className="space-y-2 max-h-32 overflow-y-auto">
                        {getMatchingDepartments(selectedHospital).map(dept => (
                          <label
                            key={dept.id}
                            className={`flex items-center p-2 rounded border cursor-pointer transition-colors duration-200 ${
                              selectedDepartments.includes(dept.id)
                                ? 'bg-blue-50 border-blue-600'
                                : 'border-gray-300 hover:border-gray-400'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={selectedDepartments.includes(dept.id)}
                              onChange={() => toggleDepartment(dept.id)}
                              className="sr-only"
                            />
                            <span className={`text-sm ${
                              selectedDepartments.includes(dept.id) ? 'text-blue-900' : 'text-gray-700'
                            }`}>
                              {dept.name}
                            </span>
                            {selectedDepartments.includes(dept.id) && (
                              <CheckCircle className="h-4 w-4 text-blue-600 ml-auto" />
                            )}
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Consultation Fee (₹)
                    </label>
                    <input
                      type="number"
                      min="100"
                      value={consultationFee}
                      onChange={(e) => setConsultationFee(e.target.value)}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      placeholder="Enter your consultation fee"
                    />
                  </div>
                </div>

                <div className="flex space-x-3 mt-6">
                  <button
                    type="submit"
                    disabled={selectedDepartments.length === 0}
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    Join Hospital
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowJoinForm(false);
                      setSelectedHospital('');
                      setConsultationFee('');
                      setSelectedDepartments([]);
                    }}
                    className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Current Associations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {doctor.hospitalAssociations.map((assoc) => {
          const hospital = hospitals.find(h => h.id === assoc.hospitalId);
          const departments = assoc.departmentIds.map(deptId => 
            hospital?.departments.find(dept => dept.id === deptId)
          ).filter(Boolean);

          return (
            <div key={assoc.hospitalId} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Building2 className="h-6 w-6 text-blue-600 mr-3" />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{hospital?.name}</h3>
                    <p className="text-sm text-gray-600">{hospital?.location}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center text-green-600">
                    <DollarSign className="h-4 w-4 mr-1" />
                    <span className="font-semibold">₹{assoc.consultationFee.toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-gray-500">per consultation</p>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex items-center mb-2">
                    <Users className="h-4 w-4 text-gray-600 mr-2" />
                    <span className="text-sm font-medium text-gray-700">Departments</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {departments.map((dept) => (
                      <span 
                        key={dept?.id}
                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full"
                      >
                        {dept?.name}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-3 border-t">
                  <div className="text-center">
                    <p className="text-lg font-semibold text-gray-900">
                      {assoc.availableSlots.filter(slot => !slot.isBooked).length}
                    </p>
                    <p className="text-sm text-gray-600">Available Slots</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold text-gray-900">
                      {assoc.availableSlots.filter(slot => slot.isBooked).length}
                    </p>
                    <p className="text-sm text-gray-600">Booked Slots</p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Available Hospitals */}
      {availableHospitals.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Available Hospitals</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableHospitals.map((hospital) => {
              const matchingDepts = hospital.departments.filter(dept => 
                doctor.specializations.includes(dept.name)
              );

              return (
                <div key={hospital.id} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium text-gray-900">{hospital.name}</h3>
                      <p className="text-sm text-gray-600">{hospital.location}</p>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedHospital(hospital.id);
                        setShowJoinForm(true);
                      }}
                      className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition-colors duration-200"
                    >
                      Join
                    </button>
                  </div>
                  <div>
                    <p className="text-sm text-gray-700 mb-1">Matching departments:</p>
                    <div className="flex flex-wrap gap-1">
                      {matchingDepts.map(dept => (
                        <span 
                          key={dept.id}
                          className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded"
                        >
                          {dept.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Empty States */}
      {doctor.hospitalAssociations.length === 0 && availableHospitals.length === 0 && (
        <div className="text-center py-12">
          <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Available Hospitals</h3>
          <p className="text-gray-600">
            No hospitals have departments matching your specializations ({doctor.specializations.join(', ')}).
          </p>
        </div>
      )}

      {doctor.hospitalAssociations.length === 0 && availableHospitals.length > 0 && (
        <div className="text-center py-8 bg-blue-50 rounded-xl">
          <Building2 className="h-8 w-8 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Join Hospitals</h3>
          <p className="text-gray-600 mb-4">
            There are {availableHospitals.length} hospital{availableHospitals.length !== 1 ? 's' : ''} with departments matching your specializations.
          </p>
          <button
            onClick={() => setShowJoinForm(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            <Plus className="h-4 w-4 mr-2" />
            Join Your First Hospital
          </button>
        </div>
      )}
    </div>
  );
}