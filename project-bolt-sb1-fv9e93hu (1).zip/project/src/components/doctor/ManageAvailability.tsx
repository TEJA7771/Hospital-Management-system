import React, { useState } from 'react';
import { Plus, Clock, Trash2, Calendar } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export function ManageAvailability() {
  const { state, dispatch } = useApp();
  const { currentUser, hospitals } = state;
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState('');
  const [newSlot, setNewSlot] = useState({
    date: '',
    startTime: '',
    endTime: ''
  });

  // Find current doctor
  const doctor = state.doctors.find(d => d.id === currentUser?.id);
  
  if (!doctor) return null;

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for conflicts across all hospitals
    const hasConflict = doctor.hospitalAssociations.some(assoc =>
      assoc.availableSlots.some(slot =>
        slot.date === newSlot.date &&
        ((newSlot.startTime >= slot.startTime && newSlot.startTime < slot.endTime) ||
         (newSlot.endTime > slot.startTime && newSlot.endTime <= slot.endTime) ||
         (newSlot.startTime <= slot.startTime && newSlot.endTime >= slot.endTime))
      )
    );

    if (hasConflict) {
      alert('Time slot conflicts with existing appointment across hospitals!');
      return;
    }

    const timeSlot = {
      id: `slot-${Date.now()}`,
      date: newSlot.date,
      startTime: newSlot.startTime,
      endTime: newSlot.endTime,
      isBooked: false
    };

    const updatedDoctor = {
      ...doctor,
      hospitalAssociations: doctor.hospitalAssociations.map(assoc =>
        assoc.hospitalId === selectedHospital
          ? { ...assoc, availableSlots: [...assoc.availableSlots, timeSlot] }
          : assoc
      )
    };

    dispatch({ type: 'UPDATE_DOCTOR', payload: updatedDoctor });
    setNewSlot({ date: '', startTime: '', endTime: '' });
    setShowAddForm(false);
    setSelectedHospital('');
  };

  const handleDeleteSlot = (hospitalId: string, slotId: string) => {
    const updatedDoctor = {
      ...doctor,
      hospitalAssociations: doctor.hospitalAssociations.map(assoc =>
        assoc.hospitalId === hospitalId
          ? { ...assoc, availableSlots: assoc.availableSlots.filter(slot => slot.id !== slotId) }
          : assoc
      )
    };

    dispatch({ type: 'UPDATE_DOCTOR', payload: updatedDoctor });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Manage Availability</h1>
            <p className="text-gray-600 mt-1">Set your consultation time slots</p>
          </div>
          <button
            onClick={() => setShowAddForm(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Time Slot
          </button>
        </div>
      </div>

      {/* Add Slot Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Add Time Slot</h2>
              <form onSubmit={handleAddSlot}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hospital
                    </label>
                    <select
                      value={selectedHospital}
                      onChange={(e) => setSelectedHospital(e.target.value)}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                    >
                      <option value="">Select Hospital</option>
                      {doctor.hospitalAssociations.map(assoc => {
                        const hospital = hospitals.find(h => h.id === assoc.hospitalId);
                        return (
                          <option key={assoc.hospitalId} value={assoc.hospitalId}>
                            {hospital?.name}
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Date
                    </label>
                    <input
                      type="date"
                      value={newSlot.date}
                      onChange={(e) => setNewSlot(prev => ({...prev, date: e.target.value}))}
                      min={new Date().toISOString().split('T')[0]}
                      required
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Start Time
                      </label>
                      <input
                        type="time"
                        value={newSlot.startTime}
                        onChange={(e) => setNewSlot(prev => ({...prev, startTime: e.target.value}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        End Time
                      </label>
                      <input
                        type="time"
                        value={newSlot.endTime}
                        onChange={(e) => setNewSlot(prev => ({...prev, endTime: e.target.value}))}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex space-x-3 mt-6">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    Add Slot
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddForm(false);
                      setNewSlot({ date: '', startTime: '', endTime: '' });
                      setSelectedHospital('');
                    }}
                    className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400 transition-colors duration-200"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Availability by Hospital */}
      <div className="space-y-6">
        {doctor.hospitalAssociations.map((assoc) => {
          const hospital = hospitals.find(h => h.id === assoc.hospitalId);
          const availableSlots = assoc.availableSlots.filter(slot => !slot.isBooked);
          const bookedSlots = assoc.availableSlots.filter(slot => slot.isBooked);

          return (
            <div key={assoc.hospitalId} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{hospital?.name}</h2>
                  <p className="text-gray-600">Consultation Fee: ₹{assoc.consultationFee.toLocaleString()}</p>
                </div>
                <div className="flex space-x-4 text-sm">
                  <div className="text-center">
                    <p className="text-lg font-semibold text-green-600">{availableSlots.length}</p>
                    <p className="text-gray-600">Available</p>
                  </div>
                  <div className="text-center">
                    <p className="text-lg font-semibold text-blue-600">{bookedSlots.length}</p>
                    <p className="text-gray-600">Booked</p>
                  </div>
                </div>
              </div>

              {/* Available Slots */}
              {availableSlots.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-green-600" />
                    Available Slots
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {availableSlots.map((slot) => (
                      <div key={slot.id} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{slot.date}</p>
                          <p className="text-sm text-gray-600">{slot.startTime} - {slot.endTime}</p>
                        </div>
                        <button
                          onClick={() => handleDeleteSlot(assoc.hospitalId, slot.id)}
                          className="p-1 text-red-600 hover:bg-red-100 rounded transition-colors duration-200"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Booked Slots */}
              {bookedSlots.length > 0 && (
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-3 flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                    Booked Slots
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {bookedSlots.map((slot) => (
                      <div key={slot.id} className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{slot.date}</p>
                          <p className="text-sm text-gray-600">{slot.startTime} - {slot.endTime}</p>
                          <p className="text-xs text-blue-600 mt-1">Appointment booked</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {assoc.availableSlots.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p>No time slots set for this hospital</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {doctor.hospitalAssociations.length === 0 && (
        <div className="text-center py-12">
          <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Hospital Associations</h3>
          <p className="text-gray-600">Join a hospital first to manage your availability</p>
        </div>
      )}
    </div>
  );
}