// Core entity types
export interface Hospital {
  id: string;
  name: string;
  location: string;
  departments: Department[];
  adminId: string;
}

export interface Department {
  id: string;
  name: string;
  hospitalId: string;
}

export interface Doctor {
  id: string;
  name: string;
  qualifications: string[];
  specializations: string[];
  yearsOfExperience: number;
  hospitalAssociations: HospitalAssociation[];
}

export interface HospitalAssociation {
  hospitalId: string;
  departmentIds: string[];
  consultationFee: number;
  availableSlots: TimeSlot[];
}

export interface TimeSlot {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  isBooked: boolean;
  appointmentId?: string;
}

export interface Patient {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'other';
  dateOfBirth: string;
  uniqueId: string; // Aadhar, Passport, etc.
  appointments: Appointment[];
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  hospitalId: string;
  departmentId: string;
  timeSlotId: string;
  consultationFee: number;
  date: string;
  status: 'booked' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface HospitalAdmin {
  id: string;
  name: string;
  email: string;
  hospitalId: string;
}

// User types
export type UserRole = 'hospital-admin' | 'doctor' | 'patient';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

// Common specializations
export const SPECIALIZATIONS = [
  'Cardiology',
  'Orthopedics', 
  'Pediatrics',
  'Neurology',
  'Dermatology',
  'General Medicine',
  'Surgery',
  'Gynecology',
  'Psychiatry',
  'Oncology'
] as const;

export type Specialization = typeof SPECIALIZATIONS[number];