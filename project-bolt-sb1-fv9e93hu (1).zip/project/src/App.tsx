import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { LoginPage } from './components/auth/LoginPage';
import { RegisterPage } from './components/auth/RegisterPage';
import { HospitalDashboard } from './components/hospital/HospitalDashboard';
import { ManageDepartments } from './components/hospital/ManageDepartments';
import { DoctorDashboard } from './components/doctor/DoctorDashboard';
import { ManageAvailability } from './components/doctor/ManageAvailability';
import { AssociateHospital } from './components/doctor/AssociateHospital';
import { PatientDashboard } from './components/patient/PatientDashboard';
import { BookAppointment } from './components/patient/BookAppointment';

function App() {
  const [currentView, setCurrentView] = useState('login');

  const renderView = () => {
    switch (currentView) {
      case 'login':
        return <LoginPage onViewChange={setCurrentView} />;
      case 'register':
        return <RegisterPage onViewChange={setCurrentView} />;
      case 'dashboard':
        return <HospitalDashboard />;
      case 'manage-departments':
        return <ManageDepartments />;
      case 'doctor-dashboard':
        return <DoctorDashboard />;
      case 'manage-availability':
        return <ManageAvailability />;
      case 'associate-hospital':
        return <AssociateHospital />;
      case 'patient-dashboard':
        return <PatientDashboard />;
      case 'book-appointment':
        return <BookAppointment />;
      default:
        return <LoginPage onViewChange={setCurrentView} />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50">
        {currentView !== 'login' && currentView !== 'register' && (
          <Navbar currentView={currentView} onViewChange={setCurrentView} />
        )}
        {renderView()}
      </div>
    </AppProvider>
  );
}

export default App;